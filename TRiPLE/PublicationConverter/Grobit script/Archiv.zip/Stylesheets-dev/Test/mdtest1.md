Paragraphs are separated by a blank line.

2nd paragraph. *Italic*, **bold**, `monospace`, ~~deleted~~. Itemized lists
look like:

  * this one
  * that one
  * the other one

3rd paragraph. _Italic_, __bold__, `monospace`. Itemized lists
Note that --- not considering the asterisk --- the actual text
content starts at 4-columns in.

> Block quotes are
> written like so.
> They can span multiple paragraphs,
> if you like.

    Block of code indented
    written like so.
    They can span multiple paragraphs,
    End of indented code

```
 Blocks of FENCED  code
   written like so.
 End of of fenced code
```

http://github.org
http://localhost
http://localhost/a/b/4/test/ala.php?o=a
http://localhost/a/b/4/test/?o=a
http://localhost/a/b/4/test/?o=a&u=33&e34=7a


## An h2 header


## Another h2 header
### Another h3 header

Note again how the actual text starts at 4 columns in (4 characters
from the left side). Here's a code sample:

    # Let me re-iterate ...
    for i in 1 .. 10 { do-something(i) }

As you probably guessed, indented 4 spaces. By the way, instead of
Indenting the block,  you can use delimited blocks see link [Visit GitHub!](www.github.com) , if you like.

Done.
