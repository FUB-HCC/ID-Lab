experimentation with conversion from Word for scientific journals
