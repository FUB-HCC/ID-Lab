ENRICH EU project on manuscript description
