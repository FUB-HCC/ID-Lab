Specific case of epub intended for conversion to Kindle MOBI format
